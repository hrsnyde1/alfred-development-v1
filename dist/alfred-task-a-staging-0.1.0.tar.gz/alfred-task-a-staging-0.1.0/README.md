# Task A staging release candidate — inactive

This tree is **planning, proposed code and isolated tests only**. It is not an installed service, a Gateway task, an approval, or an execution grant. Nothing here is called by production Hermes, Photon or the real Development Gateway. Task B remains blocked until formal ADR recording, separate Task A protected-path authorization, implementation in an approved test environment, and independent security acceptance.

## Inventory

| Component | Staged artifact | Current limit |
| --- | --- | --- |
| Conditional ADR record | `APPROVAL_RECORD_CANDIDATE.json`, generated `adr-0003-conditional-photon-front.proposed.patch` | Formal authoritative ADR recording is pending. Patch is checked against pinned source and never applied here. |
| Dedicated identities, system units, DAC/ACL | `templates/systemd/`, `templates/permissions/paths.json` | Candidates only; UID/group creation, mounts and real systemd confinement untested. |
| Photon event binding | `task_a/broker.py` | Explicit sidecar `sender.id`, DM, text, time, kernel UDS peer UID and opaque handle are checked in synthetic tests. Actual Photon SDK/sidecar ownership and Hermes forwarding are **not integrated**. Synthetic submission defaults disabled. |
| Lab inbox writer | `task_a/transport.py` | Only marked temporary roots; existing `alfred.devreq/1` JSON, atomic write-ahead ledger, exact retry and conflict refusal. No live inbox path accepted. |
| Gateway/Hermes source copy prototype | `task_a/promote.py`, `templates/registry/projects.yaml` | Clean full commit + tracked file hashes and versioned selector in a disposable root. The human has not yet pinned a Gateway lab commit. Trusted remote provenance, dependency/launcher packaging, root ownership and production rollback require operator review. |
| Evidence Bridge | `task_a/evidence.py`, pinned v0.2.1 SHA-256 manifest | Reads installed plugin for verification and copies only into an isolated root. No live report ownership or permission changes. UID-31012 live reader compatibility is unverified. |
| Transaction/recovery/rollback | `task_a/release.py`, `task_a/release_cli.py` | Checks payload/baseline hashes, preserves backups, refuses interrupted state, recovers/rolls back in marked temporary roots. It neither installs accounts/ACLs/units nor restarts services. |
| Tests and evidence | `tests/`, `TEST_RESULTS.md`, `INDEPENDENT_SECURITY_REVIEW.md` | Static and unprivileged results are separated from privileged and production claims. |

The root marker `.task-a-isolated-root` with exact contents `TASK_A_LAB_ONLY\n` is required for all mutable prototype roots. The code additionally requires the root to resolve below the system temporary directory. This is a staging safety guard, not a production authorization mechanism.

## Unfinished integration boundary

The installed Hermes Photon adapter currently supervises the Node sidecar inside Hermes, requires Photon project credentials at connect time, and falls back from missing `sender.id` to phone/space for normal routing. The Task A broker rejects that fallback, but its socket reader has **no connected production Photon sidecar**. The candidate systemd broker `ExecStart` is an uninstalled target path and must not be started until a reviewed sidecar split, direct event feed, Hermes forwarding path and credential separation are implemented and tested. The candidate units parse in a disposable systemd root; that proves syntax, not startability or confinement.

## Authority

The Gateway alone validates the envelope, resolves `project_hint` from a protected lab registry and files any canonical `proposed` spec. The lab run-once test is the only Gateway invocation here and uses a disposable repository. No direct Kanban intake, approval, execution, publication, merge, deployment, real company repository or permanent Codex runtime is provided.

See `PROTECTED_PATHS.md` for the reviewed production diff inventory, `MIGRATION_RECOVERY.md` for the proposed transaction order, and `INDEPENDENT_SECURITY_REVIEW.md` for acceptance blockers.
