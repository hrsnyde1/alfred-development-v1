"""Execute the proposed adapter's exact binding methods without installing it."""

from __future__ import annotations

import ast
import asyncio
import contextvars
import logging
from pathlib import Path
from types import SimpleNamespace

import make_photon_patch


def _isolated_adapter_methods():
    original = (make_photon_patch.UPSTREAM / "plugins/platforms/photon/adapter.py").read_text()
    revised = make_photon_patch.adapter(original)
    assert "_task_a_handles" not in revised
    tree = ast.parse(revised)
    adapter = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == "PhotonAdapter")
    methods = [node for node in adapter.body if isinstance(node, ast.AsyncFunctionDef)
               and node.name in {"_on_inbound_line", "_sidecar_call"}]
    assert len(methods) == 2
    miniature = ast.ClassDef(name="MiniAdapter", bases=[], keywords=[], body=methods, decorator_list=[])
    source = "from __future__ import annotations\n" + ast.unparse(miniature)
    posts = []

    class Response:
        status_code = 200
        text = ""
        def json(self):
            return {"ok": True, "messageId": "stub"}

    class Client:
        def __init__(self, **_kwargs):
            pass
        async def __aenter__(self):
            return self
        async def __aexit__(self, *_args):
            return False
        async def post(self, url, *, json, headers):
            posts.append((url, json, headers))
            return Response()

    namespace = {"contextvars": contextvars, "asyncio": asyncio, "logging": logging,
                 "json": __import__("json"), "logger": logging.getLogger("task-a-test"),
                 "_task_a_reply_binding": contextvars.ContextVar("review_photon_binding", default=None),
                 "httpx": SimpleNamespace(AsyncHTTPTransport=lambda **_kw: object(), AsyncClient=Client)}
    exec(compile(source, "<reviewed patched adapter methods>", "exec"), namespace)
    instance = namespace["MiniAdapter"]()
    instance._task_a_socket = "/tmp/synthetic-only.sock"
    instance._http_client = object()
    instance._dedup = SimpleNamespace(is_duplicate=lambda _message: False)
    instance._note_upstream_activity = lambda: None
    instance._sidecar_url = lambda path: "http://task-a" + path
    instance._sidecar_headers = lambda: {}
    return instance, posts


def test_overlapping_same_chat_turns_keep_original_handles():
    async def scenario():
        adapter, posts = _isolated_adapter_methods()
        gates = {"m1": asyncio.Event(), "m2": asyncio.Event()}
        tasks = []
        async def dispatch(event):
            async def delayed():
                await gates[event["messageId"]].wait()
                await adapter._sidecar_call("/send", {"spaceId": "same-space", "text": event["messageId"]})
            tasks.append(asyncio.create_task(delayed()))
        adapter._dispatch_inbound = dispatch
        for message, handle in (("m1", "handle-one"), ("m2", "handle-two")):
            await adapter._on_inbound_line(__import__("json").dumps(
                {"messageId": message, "handle": handle, "space": {"id": "same-space"}}))
        gates["m2"].set()
        await asyncio.sleep(0)
        gates["m1"].set()
        await asyncio.gather(*tasks)
        assert [(body["handle"], body["text"]) for _url, body, _headers in posts] == [
            ("handle-two", "m2"), ("handle-one", "m1")]
    asyncio.run(scenario())


def test_missing_or_mismatched_turn_context_is_denied():
    async def scenario():
        adapter, posts = _isolated_adapter_methods()
        try:
            await adapter._sidecar_call("/send", {"spaceId": "same-space", "text": "no context"})
        except RuntimeError as exc:
            assert "missing or mismatched" in str(exc)
        else:
            raise AssertionError("missing handle accepted")
        async def dispatch(_event):
            try:
                await adapter._sidecar_call("/send", {"spaceId": "other-space", "text": "mismatch"})
            except RuntimeError as exc:
                assert "missing or mismatched" in str(exc)
            else:
                raise AssertionError("destination substitution accepted")
        adapter._dispatch_inbound = dispatch
        await adapter._on_inbound_line('{"messageId":"m1","handle":"bound","space":{"id":"same-space"}}')
        assert posts == []
    asyncio.run(scenario())


def test_durable_retry_is_not_swallowed_by_legacy_message_dedup():
    async def scenario():
        adapter, posts = _isolated_adapter_methods()
        adapter._dedup = SimpleNamespace(is_duplicate=lambda _message: True)
        async def dispatch(event):
            await adapter._sidecar_call("/send", {"spaceId": "same-space", "text": event["messageId"]})
        adapter._dispatch_inbound = dispatch
        await adapter._on_inbound_line('{"messageId":"retry","handle":"exact","space":{"id":"same-space"}}')
        assert posts[0][1] == {"handle": "exact", "text": "retry"}
    asyncio.run(scenario())
