# Photon Task A v0.1.3 threat model

This is a staging design for the isolated `dev-001` lab. The protected Photon
identity owns the only Spectrum connection, project credentials, private
sidecar socket, event spool, journal, and lab inbox writer. Hermes is an
untrusted caller of the restricted Unix socket. The lab Gateway alone parses
and files canonical `alfred.devreq/1` envelopes. No Task B authority exists.

## Assets and attacker capabilities

An attacker controlling Hermes prompts, tools, plugins, or its Unix socket
requests may choose text, paths, recipient strings, envelope fields and call
timing. The attacker may open many stalled connections and replay previously
seen handles. They must not be able to read Photon credentials, private SDK
events, unrelated inbox entries, or Gateway state, nor send to an unapproved
destination or stop the sidecar. A compromised protected Photon UID is outside
this isolation boundary and must be treated as a full intake compromise.

## Controls proposed in v0.1.3

- Systemd owns the restricted socket (`alfredphoton:alfredhermes`, `0660`);
  the protected runtime directory is `0751`. The private sidecar socket is
  `0600`, under the protected UID. Both interfaces check kernel peer UID.
  LoadCredential files and the single child process are confined to the
  protected service. `task_a/service.py` supervises launch, health, restart
  and termination. Node stdout/stderr are discarded because SDK diagnostics
  are not proven privacy-safe; the broker writes bounded code-only audit.
- The sidecar fsyncs an owner-only spool record and directory before sending
  an event. The broker fsyncs its owner-only journal before acknowledging the
  sidecar. The sidecar marks a live SDK message read only after acceptance.
  Unavailable admission leaves the spool record pending; explicit policy
  rejection removes it without a read receipt. Oversized and normalization
  failures become durable content-free rejection records. A spool write
  failure terminates the sidecar for supervised recovery.
- Each journal record has a random handle, explicit sender, destination,
  message and time. The adapter uses task context for the exact inbound turn;
  no latest-handle-per-chat map remains. Legacy message deduplication is
  disabled in Task A mode so journal retries reach Hermes. A reply reserves
  its handle durably before external send. Uncertain sends cannot retry under
  the same handle. A failed turn may replay at most three times in one broker
  lifetime; delayed work is audited and remains on disk for restart recovery.
- The restricted API has bounded text replies and canonical lab submissions
  only. Attachment paths and private control routes are absent from Hermes.
  The inbox is search/write-only to the broker through `O_PATH`, while the
  setgid directory and `0640` files provide Gateway group read. Publication
  uses no-clobber hard-link commit, file fsync and filesystem sync.
- The HTTP listener caps concurrent handlers at 32, backlog at 32 and POST
  request lifetime at five seconds. Its event queue and persistent journal
  each cap at 1,024 entries. Audit storage caps at 4 MiB and fails closed.

## Residual and independent acceptance risks

The installed Photon SDK may treat an iterator yield as acknowledgement even
if the sidecar crashes before its spool fsync. Its replay and read-receipt
semantics need live verification with a disposable account. Cross-UID DAC,
systemd directory ownership, group inheritance, socket activation and
service mount restrictions need separate Linux testing. Node or broker code
compromise under the protected UID can access protected state and the lab
inbox. Operator rotation of the bounded audit log must be designed before
production. The broad legacy Hermes Photon regressions did not complete in
this sandbox; their media assumptions require explicit compatibility review.
