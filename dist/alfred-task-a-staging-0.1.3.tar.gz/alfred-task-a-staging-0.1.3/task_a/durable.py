"""Protected, bounded Photon event journal for at-least-once front delivery.

The journal is owned by the protected Photon identity. It records an event
before the sidecar is acknowledged and records a reply reservation before any
external send. A replay after a crash reuses the same handle and destination.
"""

from __future__ import annotations

import datetime as dt
import hashlib
import hmac
import json
import os
from pathlib import Path
import stat

from .broker import AdmittedEvent, AdmissionError, PhotonIngressPrototype
from .transport import _atomic, _object_pairs


class JournalError(ValueError):
    pass


class DurableEventJournal:
    def __init__(self, directory: Path, ingress: PhotonIngressPrototype, *, key: bytes):
        if len(key) < 32:
            raise JournalError("journal key too short")
        info = directory.lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid() or stat.S_IMODE(info.st_mode) != 0o700:
            raise JournalError("unsafe protected event journal")
        self.directory = directory
        self.ingress = ingress
        self.key = key
        self.records: dict[str, dict] = {}
        self.by_event: dict[str, str] = {}
        self._load()

    def _name(self, event_key: str) -> str:
        return hmac.new(self.key, event_key.encode(), hashlib.sha256).hexdigest() + ".json"

    def _persist(self, record: dict) -> None:
        fd = os.open(self.directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            _atomic(fd, self._name(record["event_key"]), json.dumps(record, sort_keys=True, separators=(",", ":")).encode())
        finally:
            os.close(fd)

    def _load(self) -> None:
        paths = list(self.directory.iterdir())
        if len(paths) > 1024:
            raise JournalError("event journal capacity exceeded")
        for path in paths:
            if not path.name.endswith(".json"):
                continue
            info = path.lstat()
            if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_uid != os.getuid() or info.st_size > 65536:
                raise JournalError("unsafe event record")
            record = json.loads(path.read_bytes(), object_pairs_hook=_object_pairs)
            if not isinstance(record, dict) or set(record) != {"event_key", "handle", "sender", "space", "message", "text", "timestamp", "reply_state"}:
                raise JournalError("invalid event record")
            if path.name != self._name(record["event_key"]) or record["reply_state"] not in ("ready", "reserved"):
                raise JournalError("invalid event record identity")
            event = AdmittedEvent(record["sender"], record["space"], record["message"], record["text"],
                                  dt.datetime.fromisoformat(record["timestamp"]))
            if event.key != record["event_key"] or record["handle"] in self.records or event.key in self.by_event:
                raise JournalError("conflicting event record")
            # Keep old records for deduplication, but only live handles can be
            # used for replies or replay to Hermes.
            self.records[record["handle"]] = record
            self.by_event[event.key] = record["handle"]
            if 0 <= (self.ingress.now() - event.timestamp).total_seconds() <= self.ingress.ttl_seconds:
                self.ingress._events[record["handle"]] = event
                self.ingress._event_keys.add(event.key)
        self._prune()

    def _prune(self) -> None:
        expired = [handle for handle in self.records if handle not in self.ingress._events]
        if not expired:
            return
        fd = os.open(self.directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            for handle in expired:
                record = self.records.pop(handle)
                self.by_event.pop(record["event_key"], None)
                os.unlink(self._name(record["event_key"]), dir_fd=fd)
            os.fsync(fd)
        finally:
            os.close(fd)

    def accept(self, event: dict, *, observed_uid: int) -> tuple[str, bool]:
        if observed_uid != self.ingress.sidecar_uid:
            raise AdmissionError("untrusted ingress process")
        try:
            key = "\0".join((event["sender"]["id"], event["space"]["id"], event["messageId"]))
        except (TypeError, KeyError, AttributeError) as exc:
            raise AdmissionError("invalid event identity") from exc
        existing = self.by_event.get(key)
        if existing:
            record = self.records[existing]
            content = event.get("content")
            if (not isinstance(content, dict) or record["text"] != content.get("text")
                    or content.get("type") != "text" or content.get("forwarded") or content.get("quoted")
                    or event.get("platform") != "iMessage" or not isinstance(event.get("space"), dict)
                    or event["space"].get("type") != "dm"
                    or event.get("timestamp") not in (record["timestamp"], record["timestamp"].replace("+00:00", "Z"))):
                raise AdmissionError("conflicting replay")
            admitted = self.ingress._events.get(existing)
            if admitted is None or not 0 <= (self.ingress.now() - admitted.timestamp).total_seconds() <= self.ingress.ttl_seconds:
                raise AdmissionError("expired event replay")
            return existing, False
        self.ingress._prune_expired()
        self._prune()
        handle = self.ingress._admit(event, observed_uid)
        admitted = self.ingress._events[handle]
        record = {"event_key": admitted.key, "handle": handle, "sender": admitted.sender,
                  "space": admitted.space, "message": admitted.message, "text": admitted.text,
                  "timestamp": admitted.timestamp.isoformat(), "reply_state": "ready"}
        try:
            self._persist(record)
        except BaseException:
            self.ingress._events.pop(handle, None)
            self.ingress._event_keys.discard(admitted.key)
            raise
        self.records[handle] = record
        self.by_event[admitted.key] = handle
        return handle, True

    def reserve_reply(self, handle: str) -> None:
        record = self.records.get(handle)
        if record is None or record["reply_state"] != "ready" or handle not in self.ingress._events:
            raise JournalError("unknown, expired or used event handle")
        updated = {**record, "reply_state": "reserved"}
        self._persist(updated)
        self.records[handle] = updated

    def recoverable(self) -> list[str]:
        return [handle for handle, record in self.records.items() if handle in self.ingress._events
                and record["reply_state"] == "ready"]
