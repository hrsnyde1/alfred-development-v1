# Task A v0.1.3 staging verification — 2026-10-14

No installed Hermes, Photon or Gateway file, identity or service was changed.
No real Photon message, protected Gateway operation, Task B work or Gateway
task creation occurred. These are synthetic and disposable tests, not live
Photon authentication or production isolation.

## Successful checks

From this Task A workspace:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 make_photon_patch.py
git -C /home/alfred/.hermes/hermes-agent apply --check /home/alfred/alfred-development-lab/milestone2/task-a/patches/photon-secure-front.proposed.patch
PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 TMPDIR=/tmp PYTHONPATH=/home/alfred/.cache/uv/archive-v0/DK4n9G7xyVKZZ3KJ:/home/alfred/.cache/uv/archive-v0/Vd_UqZgwiCKPnjqT:/home/alfred/.cache/uv/archive-v0/yS-fDywY2zPwXlrb:/home/alfred/.cache/uv/archive-v0/zKTheZIblUKblIHq:/home/alfred/.cache/uv/archive-v0/0oYfnLum5o7lxH7f:/home/alfred/.cache/uv/archive-v0/I72leh8kvOwfxzxF:/home/alfred/.cache/uv/archive-v0/km5q1G6DQSLWVkaR:/home/alfred/.cache/uv/archive-v0/HXHkS5Ryw6x2BjKb:/home/alfred/.cache/uv/archive-v0/q2KGeVV7WpodnnBE:/home/alfred/.cache/uv/archive-v0/H6nw76zWZtAyqp8H:/home/alfred/.cache/uv/archive-v0/tnPDiOo2cFPD0KWg /home/alfred/alfred-development-lab/milestone2/.test-venv/bin/python -m pytest -q -p no:cacheprovider --basetemp=/tmp/task-a-remediate-final-2 tests -k 'not disposable_gateway_files_one_unapproved_task_after_broker_write'
```

Final suite count: **78 passed, 5 skipped, 1 deselected**. It covers deterministic
upstream patch reproduction, Python AST and Node syntax, synthetic spool and
journal failure injection, disposable child launch/shutdown, systemd parser,
Gateway envelope contract, Evidence Bridge hashes, and negative security tests.

## Installed Hermes Photon baseline investigation

The following equivalent commands set all inputs explicitly and ran from
`/home/alfred/.hermes/hermes-agent`:

```sh
export HOME=/home/alfred/alfred-development-lab/milestone2/task-a/.regression-home
export TMPDIR=/home/alfred/alfred-development-lab/milestone2/task-a/.regression-home
export PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
export PYTHONPATH=/home/alfred/.cache/uv/archive-v0/DK4n9G7xyVKZZ3KJ:/home/alfred/.cache/uv/archive-v0/Vd_UqZgwiCKPnjqT:/home/alfred/.cache/uv/archive-v0/yS-fDywY2zPwXlrb:/home/alfred/.cache/uv/archive-v0/zKTheZIblUKblIHq:/home/alfred/.cache/uv/archive-v0/0oYfnLum5o7lxH7f:/home/alfred/.cache/uv/archive-v0/I72leh8kvOwfxzxF:/home/alfred/.cache/uv/archive-v0/km5q1G6DQSLWVkaR:/home/alfred/.cache/uv/archive-v0/HXHkS5Ryw6x2BjKb:/home/alfred/.cache/uv/archive-v0/q2KGeVV7WpodnnBE:/home/alfred/.cache/uv/archive-v0/H6nw76zWZtAyqp8H:/home/alfred/.cache/uv/archive-v0/tnPDiOo2cFPD0KWg
timeout 30s /home/alfred/alfred-development-lab/milestone2/.test-venv/bin/python -m pytest -q -p no:cacheprovider --basetemp=/home/alfred/alfred-development-lab/milestone2/task-a/.regression-home/pytest-auth tests/plugins/platforms/photon/test_auth.py
timeout 45s /home/alfred/alfred-development-lab/milestone2/.test-venv/bin/python -m pytest -q -p no:cacheprovider --basetemp=/home/alfred/alfred-development-lab/milestone2/task-a/.regression-home/pytest-broad tests/plugins/platforms/photon
timeout 5s /home/alfred/alfred-development-lab/milestone2/.test-venv/bin/python -c 'import asyncio; print(asyncio.run(asyncio.to_thread(lambda: 1)))'
```

The auth module passed **19/19** against unchanged installed source. The
broad run finished **64 passed, 76 failed, 8 errors, 2 skipped** and is not a
passing regression. This harness lacks `pytest-asyncio`, and Node was absent
from its PATH; eight errors include Node invocation failure. Many async tests
failed or skipped before adapter behavior was exercised. The standalone
`asyncio.to_thread` command timed out after five seconds (exit 124),
reproducing the sandbox thread problem behind the earlier stalled media test.
The legacy media tests assert `/send-attachment` path semantics removed from
Task A mode. Their compatibility contract needs explicit review, not silent
exclusion. No upstream test result is represented as patched-adapter success.

## Unexecuted or sandbox-blocked checks

- One staging test invokes the real Gateway dispatcher and creates a
  disposable task record. It was deselected because this run forbids even lab
  development task creation.
- Four Unix socket bind tests and one socketpair send test skipped after
  sandbox `EPERM`. They require a separately authorized isolated Linux host.
- Cross-UID inbox ACL and Gateway reads, actual systemd socket activation,
  service namespace and credential ownership, 32-client slowloris soak, real
  Photon stream replay/read receipt, and patched Hermes compatibility are
  unverified. Evidence Bridge v0.2.1 hashes and copies have staging coverage;
  live two-tool behavior under the proposed Hermes UID remains pending.

## Release verification

The immutable archive's outer SHA-256 and all payload SHA256SUMS entries are
verified after packaging. The exact digest and verification result are stored
in `dist/RELEASE_STATUS.txt` beside the archive. The v0.1.2 archive and
checksum remain unchanged.
