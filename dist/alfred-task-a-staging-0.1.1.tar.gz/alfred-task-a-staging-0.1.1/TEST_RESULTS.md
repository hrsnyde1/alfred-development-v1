# Task A staging validation — 2026-10-14

| Level | Result | Scope |
| --- | --- | --- |
| Static and unprivileged Task A/approval-package tests | **41 passed** | Broker explicit sender/peer logic, synthetic event handles, envelope shape, bound inbox, real Gateway dispatcher in a disposable repository, retry/crash recovery, release install/recover/rollback failure injection, source promotion/rollback, Evidence Bridge exact v0.2.1 copy/registration, unit-template parsing inside a disposable root, proposed ADR `git apply --check`, and characterization of the current sidecar path-control risk. |
| Authoritative Gateway and Photon selected regressions | **834 passed** | Existing repository tests for dispatcher, envelope, requester binding, approvals, workflow preconditions, Photon adapter and read-only status. No source changes. |
| Current Evidence Bridge selected regressions | **24 passed** | Plugin, reader and Hermes status compatibility in Hermes test environment. No production Photon call. |
| Read-only installed Evidence Bridge inventory | **PASS** | Four installed v0.2.1 payload files match pinned SHA-256; both tool registrations inspected. Original plugin/report untouched. |

All Task A mutable tests use `pytest` temporary roots with an exact marker and disposable Git repositories. The one Gateway `run_once` call used an isolated test HOME, one-project registry and repository; it filed exactly one unapproved `proposed` spec and a retry filed none. No real Gateway command was run. The staged systemd unit parser test provided dummy executables and standard targets inside an alternate temporary root; it does **not** establish actual unit startability.

During development, the interruption test exposed that the installer checked the changed baseline before reporting an unfinished transaction; check order was corrected and recovery was retested. The first alternate-root unit parser fixture lacked `sysinit.target`; the fixture was completed. A direct `systemd-analyze verify` against host paths reports the three candidate `ExecStart` binaries absent, as expected because no candidate is installed. The final isolated-root parser test passes. These earlier failures are not counted as passing production compatibility.

## Not yet verified

- No candidate UID/GID, ACL, systemd unit, mount namespace or process isolation was installed. Kernel denial for sudo, Docker/LXD, user systemd, shared UID, credentials, plugin import, coding-agent binaries, IPC and real Gateway mutation has **not** been measured.
- The broker is a disconnected prototype. Actual Photon SDK sidecar ownership, original-event feed, Hermes message forwarding, provider credentials and live principal policy are **not** integrated or tested. Current Hermes adapter autostarts its sidecar and uses a sender fallback for ordinary routing. Production compatibility is **not established**.
- **Confirmed unresolved control API risk:** the installed sidecar accepts `/send-attachment` with a caller-supplied `path`, and the existing Hermes adapter holds the sidecar bearer token. An unchanged external sidecar under broker UID 31011 would be callable to read broker-accessible files. A restricted outbound mediation contract and negative tests are required before an installation-ready release or independent OS acceptance.
- No production installer exists for account creation, ownership/ACL setup, pinned executable/dependency packaging, provider credential migration, service stop/start or systemd recovery. `task_a.release` is restricted to marked temporary roots. Root-controlled source provenance, human selection of the full lab Gateway commit and live checksum baseline remain operator/reviewer gates.
- The original Evidence Bridge report's live freshness and access by proposed UID 31012, live Photon Tool Search, Kanban state migration and old/new service exclusion remain untested.

The exact independent-review requirements are in `INDEPENDENT_SECURITY_REVIEW.md`. A passing static/unit suite alone cannot authorize Task B or deployment.
