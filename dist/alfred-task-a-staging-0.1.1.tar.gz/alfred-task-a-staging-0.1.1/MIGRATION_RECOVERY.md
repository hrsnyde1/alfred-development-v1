# Candidate migration, recovery and rollback — not executable production instructions

The current `task_a.release` CLI is **limited to marked temporary roots**. A protected production installer, account/ACL setup and migration script still require a new reviewed release. Nothing in this file authorizes service control or credential handling.

## Required deployment transaction after separate authorization

1. Record the formal ADR amendment and allocate/approve the protected Task A spec. Independently verify pinned Hermes source commit, source provenance, package checksums, Evidence Bridge v0.2.1 hashes, exact live config/unit/credential inventory, UID/GID availability, and all baseline path hashes. Refuse any mismatch.
2. On a separately approved test host, verify the root-controlled source checkout and promote a reviewed full commit plus separately hashed `alfred`/`dev-001` registry fixture to a versioned root-owned lab runtime. Pin the separate lab Python/dependency environment under `/opt/alfred-dev-gateway-lab-venv` and hash executable entry points. Preserve the prior selector, manifest and runtime copy.
3. Prepare new dedicated identities, root-owned unit files, code trees, narrow ACLs, service-private state and isolated lab repo/inbox. Do not copy real Gateway journal, grants, approvals, PAUSE/STOP, publisher or GitHub credentials. Copy only audited Hermes session/Kanban state and the exact Evidence Bridge v0.2.1 payload; leave original evidence report ownership/mode unchanged.
4. Prove the broker owns the Photon connection and that Hermes can receive normal messages without carrying Photon project credentials. Prove explicit `sender.id` binding from the original sidecar event. If this is not demonstrated, **stop before service migration**.
5. In a later approved maintenance window, stop the UID-1000 user gateway, verify it and any supervised children are gone, then install/enable the new root-managed system gateway. Never run both. No installer step restarts a service automatically. Run independent kernel-denial, service, Evidence Bridge and Photon compatibility acceptance before any lab request submission.
6. Only after Task A independent security sign-off may Task B planning or implementation begin. A lab `proposed` task never grants execution.

## Transaction state model tested in staging

`verify` checks payload and baseline SHA-256 plus baseline modes before writing. `install` records a transaction, makes and verifies preserved backups, atomically replaces each file, then marks `committed`. An interruption before the first state file or during backup causes **no target replacement**; an interruption after any replacement requires `recover`, which checks every backup and observed target before restoring. `rollback` accepts only a committed transaction whose targets still match released hashes. Both operations preserve the transaction and backup directory and mark `rolled_back`. A changed target, backup, path component or checksum refuses recovery rather than overwriting it.

The staging CLI requires `--root`, `--payload` and `--manifest`; both roots must resolve below the temporary directory and have the exact marker. Its install/recover/rollback methods do not change users, groups, ACLs, systemd or production. Failure injection covers transaction creation, each backup, the backup barrier and each file replacement. This is a **simulator**, not a deployable root installer; its ownership and multi-service activation logic are unimplemented.

## Human-controlled production rollback decision

If future approved deployment fails before the new gateway starts, stop and recover from preserved backups while the old user gateway remains inactive; verify hashes and re-enable it only by operator decision. If it fails after startup, stop the new gateway and broker, verify no new child remains, restore original system/user service choice, config/state and preserved plugin from verified backups, then restart only the previously approved service. Check both Evidence Bridge tools and absence of intake tools. Preserve the transaction, old v0.3.2 rollback, Evidence Bridge backups and audit records. A failed checksum requires investigation, not forced overwrite.
