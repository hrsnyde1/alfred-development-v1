# Task A Photon security staging evidence — 2026-10-14

All mutable test roots were under this Task A workspace. Installed Hermes,
Photon, Gateway and protected Gateway state were not changed. No real Gateway
dispatcher or Photon principal was used outside disposable test fixtures.

## Successful checks

| Check | Result | Meaning |
| --- | ---: | --- |
| Full Task A suite | 55 passed, 5 skipped | Synthetic SDK feed, event identity, replay, bounded handle reply, restricted route/schema denial, lab envelope/inbox behavior, deterministic patch, release/recovery and existing staging regressions. |
| Selected authoritative Gateway/registry regressions | 867 passed | Existing envelope, requester binding, dispatcher, approval, workflow precondition and registry tests. These read upstream source and use disposable test roots. |
| Installed Hermes Photon auth regressions | 19 passed | Existing auth tests against unchanged installed source, with an isolated Hermes test home. |
| Proposed upstream patch dry apply | pass | `git apply --check` against the exact installed source bytes; no patch applied. |
| Proposed patched source syntax | pass | Python AST parse for the adapter and Node module syntax check for the sidecar. The patched sidecar still contains one `Spectrum(...)` construction. |
| Systemd candidate parser | pass within Task A suite | `systemd-analyze verify` in a disposable root with dummy executables; syntax only. |

The five Task A skips are four Unix socket bind tests in
`tests/test_photon_front.py` and one kernel `socketpair` send test in
`tests/test_broker_transport.py`. This sandbox returned `EPERM` for those
operations. The equivalent pure policy tests passed, but they do not prove
cross-UID DAC or actual `SO_PEERCRED` behavior for the candidate processes.

## Failed or incomplete runs

- A first selected Hermes Photon run used a harness without `pytest-asyncio`
  and hit the Hermes test guard for a real-home metadata read: 20 passed and
  14 failed before the harness was corrected. This was an environment setup
  failure against unchanged installed source, not evidence that the proposed
  patch runs.
- With `pytest-asyncio` and an isolated Hermes home, the combined inbound,
  media, auth and lifecycle run reached one failure and then stalled; it was
  interrupted. A separate media-only run timed out after 20 seconds on its
  first legacy attachment test. The standalone auth module then passed 19/19.
  The media tests assert the old path-bearing interface, which the proposed
  Task A mode intentionally disables. Full patched-adapter compatibility is
  unverified.

## Guarantee boundary

The event feed used synthetic SDK-shaped objects from a test double. It
exercised the broker policy and restricted API, **not** real Photon
authentication or an active Spectrum connection. The installed sidecar and
adapter remain unchanged. The staging runner and proposed systemd units have
not been started under separate UIDs. UID/group allocation, socket owner and
group, `SO_PEERCRED`, ACLs, mount/systemd confinement, credential migration,
single-connection cutover, and kernel denial of Hermes access to private
sidecar control and protected Gateway files all remain for independent OS
testing. Live Photon text and attachment compatibility are not verified.

See `INDEPENDENT_SECURITY_REVIEW.md` and `ATTACHMENT_COMPATIBILITY.md` for
the acceptance procedure and intentionally disabled features.
