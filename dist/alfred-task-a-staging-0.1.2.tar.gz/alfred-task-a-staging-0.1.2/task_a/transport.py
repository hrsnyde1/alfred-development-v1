"""Staging-only, crash-safe writer for the Gateway's *lab* Hermes inbox.

This is a transport, not a Gateway or an approval authority. The protected
Gateway validates and files each envelope. All paths must be inside a marked
temporary root; production use requires a separately reviewed release.
"""

from __future__ import annotations

import base64
import fcntl
import hashlib
import hmac
import json
import os
from pathlib import Path
import re
import stat
import tempfile
import uuid


MAX_BYTES = 64 * 1024
UUID = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\Z")
TOP_LEVEL = frozenset({"protocol", "request_id", "revision", "submitted_at", "origin", "utterance", "project_hint", "intent_confidence", "draft", "answers"})


class TransportError(ValueError):
    pass


def isolated_root(root: Path) -> Path:
    root = root.resolve(strict=True)
    temporary = Path(tempfile.gettempdir()).resolve()
    if root == temporary or not root.is_relative_to(temporary):
        raise TransportError("only a marked temporary test root is permitted")
    marker = root / ".task-a-isolated-root"
    if marker.is_symlink() or not marker.is_file() or marker.read_text() != "TASK_A_LAB_ONLY\n":
        raise TransportError("missing isolated-root marker")
    return root


def _object_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise TransportError("duplicate JSON key")
        result[key] = value
    return result


def inspect_envelope(payload: bytes) -> dict:
    if not isinstance(payload, bytes) or len(payload) > MAX_BYTES or not payload:
        raise TransportError("invalid envelope size")
    try:
        doc = json.loads(payload.decode("utf-8"), object_pairs_hook=_object_pairs)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise TransportError("malformed envelope") from exc
    if not isinstance(doc, dict) or set(doc) != TOP_LEVEL or doc.get("protocol") != "alfred.devreq/1":
        raise TransportError("not the bounded canonical envelope shape")
    if not isinstance(doc.get("request_id"), str) or not UUID.fullmatch(doc["request_id"]):
        raise TransportError("invalid request ID")
    if type(doc.get("revision")) is not int or doc["revision"] != 1:
        raise TransportError("Task A fixture accepts revision 1 only")
    return doc


def _open_dir(path: Path) -> int:
    if path.is_symlink():
        raise TransportError("symlink directory refused")
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    if not stat.S_ISDIR(os.fstat(fd).st_mode):
        os.close(fd)
        raise TransportError("not a directory")
    return fd


def _read_file(directory_fd: int, name: str) -> bytes | None:
    try:
        fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=directory_fd)
    except FileNotFoundError:
        return None
    with os.fdopen(fd, "rb") as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_size > 2 * MAX_BYTES:
            raise TransportError("unsafe existing file")
        return stream.read(2 * MAX_BYTES + 1)


def _atomic(directory_fd: int, name: str, payload: bytes, mode: int = 0o600) -> None:
    temporary = f".task-a-{uuid.uuid4().hex}.tmp"
    fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, mode, dir_fd=directory_fd)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, name, src_dir_fd=directory_fd, dst_dir_fd=directory_fd)
        os.fsync(directory_fd)
    finally:
        try:
            os.unlink(temporary, dir_fd=directory_fd)
        except FileNotFoundError:
            pass


class LabInboxTransport:
    """One stable envelope per event key, with a write-ahead private ledger."""

    def __init__(self, root: Path, inbox: Path, ledger: Path, *, secret: bytes):
        self.root = isolated_root(root)
        self.inbox = inbox
        self.ledger = ledger
        if not secret or len(secret) < 16:
            raise TransportError("missing broker ledger key")
        self.secret = secret
        for path in (inbox, ledger):
            if not path.resolve(strict=True).is_relative_to(self.root):
                raise TransportError("path outside isolated root")
            os.close(_open_dir(path))

    def _key(self, event_key: str) -> str:
        if not isinstance(event_key, str) or not event_key or len(event_key) > 512:
            raise TransportError("invalid event key")
        return hmac.new(self.secret, event_key.encode(), hashlib.sha256).hexdigest() + ".json"

    def submit(self, event_key: str, payload: bytes, *, fail_at: str | None = None) -> str:
        doc = inspect_envelope(payload)
        name = doc["request_id"] + ".json"
        ledger_name = self._key(event_key)
        ledger_fd = _open_dir(self.ledger)
        inbox_fd = _open_dir(self.inbox)
        try:
            lock_fd = os.open(".task-a-lock", os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600, dir_fd=ledger_fd)
            try:
                fcntl.flock(lock_fd, fcntl.LOCK_EX)
                prior = _read_file(ledger_fd, ledger_name)
                digest = hashlib.sha256(payload).hexdigest()
                if prior is None:
                    record = {"request_id": doc["request_id"], "sha256": digest,
                              "bytes": base64.b64encode(payload).decode("ascii"), "state": "prepared"}
                    _atomic(ledger_fd, ledger_name, json.dumps(record, sort_keys=True).encode())
                    if fail_at == "after_prepare":
                        raise RuntimeError("injected crash after prepare")
                else:
                    try:
                        record = json.loads(prior)
                    except (ValueError, TypeError) as exc:
                        raise TransportError("corrupt ledger") from exc
                    if record.get("sha256") != digest or record.get("request_id") != doc["request_id"] or base64.b64decode(record.get("bytes", ""), validate=True) != payload:
                        raise TransportError("conflicting duplicate delivery")
                    if record.get("state") == "sent":
                        return doc["request_id"]
                    if record.get("state") != "prepared":
                        raise TransportError("unknown ledger state")
                existing = _read_file(inbox_fd, name)
                if existing is None:
                    _atomic(inbox_fd, name, payload, 0o640)
                elif existing != payload:
                    raise TransportError("inbox filename conflict")
                if fail_at == "after_publish":
                    raise RuntimeError("injected crash after publish")
                record["state"] = "sent"
                _atomic(ledger_fd, ledger_name, json.dumps(record, sort_keys=True).encode())
                return doc["request_id"]
            finally:
                os.close(lock_fd)
        finally:
            os.close(ledger_fd)
            os.close(inbox_fd)
