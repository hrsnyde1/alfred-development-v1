# Task A Photon split — staging design and trust boundary

This is an inactive candidate. The installed Hermes and Photon code has not changed.
The proposed upstream diff is `patches/photon-secure-front.proposed.patch`, pinned to
the installed sidecar and adapter SHA-256 values recorded in `make_photon_patch.py`.

## One Photon connection, two interfaces

1. The patched Node sidecar remains the **only** Spectrum SDK client and retains
   the single `await Spectrum(...)` connection. It runs as `alfredphoton`, reads
   Photon project credentials and the private control token, and binds only a
   `0600` Unix socket under `/run/alfred-photon-intake/`. The existing arbitrary
   filesystem-path `/send-attachment` route is removed from this candidate.
2. The protected Python front reads `/inbound` from that private socket. It
   checks the kernel peer UID before reading, validates explicit SDK-derived
   `sender.id`, DM/text/platform/time fields, rejects duplicate event identity,
   and issues a random opaque handle. It forwards a bounded normalized event
   over a separate Hermes socket. The protected front owns the authenticated
   event record and original provenance; Hermes receives a derived copy.
3. Hermes' patched adapter uses `PHOTON_TASK_A_BROKER_SOCKET` and no Photon
   credentials or sidecar bearer token. Its restricted socket supports only
   `GET /inbound`, `POST /healthz`, `POST /reply`, and `POST /submit`.
   `/reply` accepts exactly `handle` and `text` (at most 4,000 characters),
   sends at most once within five minutes, and derives the destination from
   the admitted event. It accepts no destination, path, URL, media bytes,
   shutdown command, or token from Hermes. The adapter's media helpers fail
   closed in Task A mode. Rich links, polls, reactions and typing are not
   separately exposed; text fallback is the only intended outbound channel.
4. `/submit` accepts exactly a handle and a canonical `alfred.devreq/1`
   envelope string. The protected front checks the Hermes kernel peer UID and
   binds `origin`, `utterance` and `project_hint=dev-001` to the admitted event.
   `LabInboxTransport` writes only the statically configured disposable lab
   inbox. The Gateway remains the sole authority for registry resolution and
   filing a canonical `proposed` task; no approval or execution is conveyed.

The private sidecar still has privileged endpoints other than attachments for
its own supervisor. The Python front calls only its private `/inbound` and
`/send` operations. Hermes has neither the private socket path permission nor
the token in the candidate topology. OS ownership, ACLs, peer checks and
process isolation need independent measurement on a disposable host.

## Event and reply behavior

- Original `sender.id` must match one explicit allowed principal; phone or
  space fallback is never an intake identity. Group, forwarded, quoted,
  non-text, stale, future and duplicate events are refused.
- Handles are random, bounded to 1,024 outstanding events, and pruned after
  the five-minute admission window. A reply consumes its handle before the
  private send, so an uncertain private send cannot be retried as a duplicate.
- The restricted wire schema has no generic proxy. Unknown routes return 404;
  extra fields on `/reply` and `/submit` return 400. A `SO_PEERCRED` UID check
  is required before any restricted request is handled.
- The staging runner is constrained to a marked temporary root. It can read
  only owner-owned mode-0600 token and ledger-key files inside that root.
  It accepts one socket-manager-provided Hermes listener descriptor, allowing
  the socket manager to set the Hermes group without adding that group to the
  broker process. It does not install identities or units and does not launch
  the sidecar.

## What the tests establish

Synthetic SDK event fixtures exercise sender and origin binding, replay,
destination binding, route denial, exact envelope bytes and lab-only inbox
behavior. Static patch tests prove the proposed source diff reproduces from
the pinned bytes and parses. They do **not** authenticate to Photon, measure
Unix socket DAC across UIDs, prove real sidecar startup, or prove live Hermes
message compatibility. This sandbox refused Unix socket bind/send, so those
integration probes were skipped and remain independent acceptance gates.
